@echo off
rem Abre o Mapa dos Minerais Criticos e Estrategicos num servidor local (porta 8000).
cd /d "%~dp0"
where py >nul 2>nul && (start "" http://localhost:8000/ & py -m http.server 8000 & goto :eof)
where python >nul 2>nul && (start "" http://localhost:8000/ & python -m http.server 8000 & goto :eof)
echo Python nao foi encontrado neste computador. Veja o LEIA-ME.md, secao "Como abrir".
pause

#!/bin/sh
# Abre o Mapa dos Minerais Críticos e Estratégicos num servidor local (porta 8000).
cd "$(dirname "$0")"
( sleep 1; (command -v open >/dev/null && open http://localhost:8000/) || xdg-open http://localhost:8000/ ) &
python3 -m http.server 8000

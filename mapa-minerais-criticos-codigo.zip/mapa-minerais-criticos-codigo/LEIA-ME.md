# Mapa dos Minerais Críticos e Estratégicos — pacote autônomo

Cópia completa do mapa (versão de teste v173, 09/11/2026) para rodar fora do Claude. Tudo de que a página precisa está nesta pasta: o código, as bibliotecas e os dados. Ela não depende de internet para funcionar.

## Como abrir

A página lê os dados de arquivos `.json` desta pasta. Por regra dos navegadores, isso só funciona quando a pasta é servida por um servidor web; abrir `index.html` com dois cliques mostra o mapa vazio.

1. **Windows, com Python instalado:** dois cliques em `abrir-mapa-windows.bat`. O navegador abre em `http://localhost:8000/`. Para fechar, feche a janela preta.
2. **Mac ou Linux:** dois cliques em `abrir-mapa-mac-linux.command` (ou, no terminal, `python3 -m http.server 8000` dentro da pasta).
3. **Para colegas usarem pelo navegador:** copiar a pasta inteira para qualquer servidor web estático (servidor da intranet, Azure Static Web Apps, GitHub Pages etc.). Não há banco de dados nem programa no servidor: são só arquivos. Isso costuma depender da TI do ministério.

Sem Python e sem servidor, a alternativa é a extensão "Live Server" do VS Code, que serve a pasta com um clique.

## O que tem na pasta

| Arquivo | Conteúdo |
|---|---|
| `index.html` | Todo o código da página: layout, estilos e a lógica do mapa e dos painéis (JavaScript, cerca de 1 MB) |
| `dados.json` | Base principal, lida ao abrir: lista de minerais do CIMCE, empresas e grupos, controle, destinos, árvore societária, camadas de base |
| `f1.json`, `f2.json`, `f3.json` | Processos ANM das classes 1, 2 e 3 de minerais, carregados quando a classe é escolhida |
| `ev/00.json` a `ev/47.json` | Eventos de cada processo no Cadastro Mineiro (cessões, onerações, arrendamentos, relatórios), repartidos em 48 arquivos |
| `ue.json` | Situação e eventos dos processos (códigos de evento do Cadastro Mineiro) |
| `terr.json` | Territórios quilombolas, assentamentos, áreas militares e faixa de fronteira |
| `prodesidx.json` e `prodes/` | Desmatamento (PRODES) em blocos geográficos |
| `aguaest.json`, `aguainfo.json`, `outorgas.json` | Estresse hídrico por microbacia e outorgas de água |
| `apbio.json` | Áreas prioritárias para a biodiversidade |
| `cav.json` | Cavernas (CANIE, ICMBio/CECAV) |
| `ene.json` | Subestações e linhas de transmissão |
| `sgb.json` | Dados do Serviço Geológico do Brasil |
| `enx.json` | Usinas de geração (ANEEL/SIGA) e infraestrutura de gás (EPE) |
| `tar.json` | Tarifas de energia das distribuidoras (ANEEL) |
| `pr.json` | Rota provável de exportação: porto e modo de transporte por estado e mineral |
| `esc.json` | Custos de frete e obras de escoamento não concluídas (simulação) |
| `tsb.json` | Checagem pela Taxonomia Sustentável Brasileira (caderno CNAE B) |
| `ind.json`, `urb.json` | Indústria ligada aos minerais (CNPJ) e usinas de beneficiamento declaradas à ANM |
| `est.json` | Estabelecimentos (CNPJ) por atividade e município, usados com os coprodutos e rejeitos de cada mineral |
| `rjx.json`, `rjm.json` | Indústrias de minerais não metálicos (cimento, cal, cerâmica, vidro, fertilizantes), do CNPJ |
| `for.json` | Fornecedores da mineração (explosivos, máquinas, apoio à lavra, estudos geológicos), do CNPJ |
| `mun.json`, `munp/` | Indicadores por município e contornos municipais por UF |
| `choque.json` | Simulação de choque de preço de insumos (IBGE: PIA-Empresa e Tabelas de Recursos e Usos) |
| `world.json` | Contorno dos países (painel de geopolítica) |
| `banco/` | O que o artefato guardava no banco do Claude: cessões e operações da varredura diária, acordos, monitor geopolítico e notícias, exportados em 09/11/2026 |
| `vendor/` | Bibliotecas usadas pela página: Leaflet 1.9.4 (mapa) e TopoJSON 3.0.2, com as licenças |

## O que foi adaptado em relação ao artefato

- A base principal saiu de dentro do HTML para `dados.json`.
- As bibliotecas, antes buscadas na internet (cdnjs), agora vêm de `vendor/`.
- Um trecho curto no início do código, marcado como "Fora do Claude", faz a página ler `banco/*.json` no lugar do banco do Claude. Dentro do Claude esse trecho não faz nada.
- As exportações em CSV e Markdown usam o download comum do navegador.

O conteúdo do mapa, as fontes e os textos são os mesmos da v173.

## Atualização

Este pacote é um retrato de 09/11/2026. A varredura diária que alimenta o artefato no Claude não roda aqui. Para atualizar, é preciso substituir os arquivos de dados (os nomes e formatos são os mesmos) ou gerar um pacote novo a partir do artefato.

## Para trabalhar com o Copilot

- O pacote completo tem cerca de 110 MB, acima do que um chat costuma aceitar como anexo. Para o Copilot entender ou alterar o mapa, o que interessa é `index.html` com este LEIA-ME; os dados não precisam ir junto.
- `index.html` concentra toda a lógica num arquivo grande. Pedidos pontuais ("mude o texto da legenda X", "acrescente a coluna Y na exportação") funcionam melhor do que pedir para reescrever a página.
- Cada informação do mapa vem com fonte e "Como conferir". Ao alterar dados, vale manter esse padrão.
